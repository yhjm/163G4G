package com.qhit.lh.g4.zzh.exam.common.utils;

public class Constans {
	public static final String VIEW_LOGIN = "view_login";
}
